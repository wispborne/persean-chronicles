#!/bin/sh

### Edit
# Your mod name. The version number will be attached to this to form "My-Mod-1.0.0"
MOD_FOLDER_NAME=Persean-Chronicles
###


chmod +x ./zipMod.sh
sh ./zipMod.sh "./../.." "$MOD_FOLDER_NAME"