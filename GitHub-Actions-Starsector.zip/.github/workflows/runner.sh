#!/bin/sh

### Edit
# Your mod name. The version number will be attached to this to form "My-Mod-1.0.0"
MOD_FOLDER_NAME=My-Mod
###


chmod +x ./zipMod.sh
./zipMod.sh "$MOD_FOLDER_NAME"